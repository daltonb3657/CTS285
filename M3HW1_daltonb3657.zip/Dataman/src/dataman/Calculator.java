/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dataman;

public class Calculator 
{
    public  static double doAddition(double numOne, double numTwo)
    {

        return numOne + numTwo;
    }

    public  static double doSubtraction(double numOne, double numTwo)
    {

        return numOne - numTwo;
    }

    public  static double doMultiplication(double numOne, double numTwo)
    {

        return numOne * numTwo;
    }

    public  static double doDivision(double numOne, double numTwo)
    {

        return numOne / numTwo;
    }
}
