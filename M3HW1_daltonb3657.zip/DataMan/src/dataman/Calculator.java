package dataman;

public class Calculator
{
    public  static double doAddition(double numOne, double numTwo)
    {

        return numOne + numTwo;
    }

    public  static double doSubtraction(double numOne, double numTwo)
    {

        return numOne - numTwo;
    }

    public  static double doMultiplication(double numOne, double numTwo)
    {

        return numOne * numTwo;
    }

    public  static double doDivision(double numOne, double numTwo)
    {

        return numOne / numTwo;
    }
}
